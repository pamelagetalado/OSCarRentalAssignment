/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oscarrentalassignment1;

/**
 *
 * @author Pamela Getalado
 */
public class FuelPurchase
{
   private double fuelaveragecost;
   private double fuelrequired;
   private double fuelcost;
   private double fueleconomy;
   private int distancekm;
   private double fuelcostprice;
   
    
    FuelPurchase()
    {
        fuelaveragecost = 0;
        fuelrequired = 0;
        fuelcost = 0;
        fueleconomy = 0;
        fuelcostprice = 0;
    }
    
    public void setFuelaveragecost(double fuel_averagecost)
    {
        fuelaveragecost = fuel_averagecost;
    }
    
    public double getFuelaveragecost()
    {
        return fuelaveragecost;
    }
    
    public void setFuelrequired (double fuelreq)
    {
        fuelrequired = fuelreq;
    }
    
    public double getFuelrequired()
    {
        return fuelrequired;
    }
    
    public void setFuelcost(double cost)
    {
        fuelcost = cost;
    }
    
    public double getFuelcost()
    {
        return fuelcost;
    }
    
    public void setFueleconomy(double fuelecon)
    {
        fueleconomy = fuelecon;
    }
    
    public double getFueleconomy()
    {
        return fueleconomy / 100;
    }
    
    public void setDistancekm(int distance)
    {
        distancekm = distance;
    }
    
    public int getDistancekm()
    {
        return distancekm;
    }
    
    public void setFuelcostprice(double fcostprice)
    {
        fuelcostprice = fcostprice;
    }
    
    public double getFuelcostprice()
    {
        return fuelcostprice;
    }
}









