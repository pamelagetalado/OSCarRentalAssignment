
package oscarrentalassignment1;

public class PerKmRental
{
    int firstCarJourney;
    int secondCarJourney;
    int thirdCarJourney;
    int fourthCarJourney;
    
    
    PerKmRental()
    {
        firstCarJourney = 0;
        secondCarJourney = 0;
        thirdCarJourney = 0;
        fourthCarJourney = 0;
    }
    
    void setfirstCarJourney (int firstTrip)
    {
        firstCarJourney = firstTrip;
    }
    
    int getfirstCarJourney()
    {
        return firstCarJourney;
    }
    
    void setsecondCarJourney (int secondTrip)
    {
        secondCarJourney = secondTrip;
    }
    
    int getsecondCarJourney ()
    {
        return secondCarJourney;
    }
    
    void setthirdCarJourney (int thirdTrip)
    {
        thirdCarJourney = thirdTrip;
    }
    
    int getthirdCarJourney ()
    {
        return thirdCarJourney;
    }
    
    void setfourthCarJourney (int fourthTrip)
    {
        fourthCarJourney = fourthTrip;
    }
    
    int getfourthCarJourney ()
    {
        return fourthCarJourney;
    }
}

