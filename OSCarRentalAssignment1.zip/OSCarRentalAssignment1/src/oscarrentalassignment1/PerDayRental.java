/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oscarrentalassignment1;

/**
 *
 * @author Pamela Getalado
 */
public class PerDayRental
{
    //constructor
    int dayrental;
    int dayrentalcost;
    
    PerDayRental()
    {
        dayrental = 0;
        dayrentalcost = 0;
    }
    
    //Call class method to set the day rentals.
    void setDayrental (int pdayrental)
    {
        dayrental = pdayrental;
    }
    
   // displays the information
    int getDayrental()
    {
        return dayrental;
    }
    
    void setDayrentalcost (int dayrentcost)
    {
        dayrentalcost = dayrentcost;
    }
    
    int getDayrentalcost ()
    {
        return dayrentalcost * 100;
    }
}
