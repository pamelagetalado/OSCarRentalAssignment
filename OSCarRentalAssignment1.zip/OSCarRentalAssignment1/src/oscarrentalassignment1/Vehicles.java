/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oscarrentalassignment1;

/**
 *
 * @author Pamela Getalado
 */
public class Vehicles
{
    String carbrand;
    String carmodelcode;
    int carmodelyear;
    int carservice;
    int distancevehicle;
    int counter = 0;
    Journey[] temp = new Journey[6];
    
    Vehicles()
    {
        carbrand = "Unknown name";
        carmodelcode = "Unknown model";
        carmodelyear = 0;
        carservice = 0;
        distancevehicle = 0;
    }
    
    void setCarbrand(String brand)
    {
        carbrand = brand;
    }
    
    String getCarbrand()
    {
        return carbrand;
    }
    
    void setCarmodelcode(String modelcode)
    {
        carmodelcode = modelcode;
    }
    
    String getModelcode()
    {
        return carmodelcode;
    }
    
    void setCarModelyear (int modelyear)
    {
        carmodelyear = modelyear;
    }
    
    int getModelyear ()
    {
        return carmodelyear;
    }
    void setCarservice(int servicerecord)
    {
        carservice = servicerecord;
    }
    
    int getCarservice()
    {
        return carservice;
    }
    
    void setDistancevehicle(int distancekm)
    {
        distancevehicle = distancekm;
    }
    
    int getDistancevehicle()
    {
        return distancevehicle;
    }
    
    void addJourney (Journey carjourney)
    {
        temp[counter] = carjourney;
        counter++;
    }
    Journey getJourney (int index)
    {
        return temp [index];
    }
    
    void addJourneyCarTrip (Journey cartrip)
    {
        temp[counter] = cartrip;
        counter++;
    }
    
    Journey getJourneyCarTrip (int index)
    {
        return temp [index];
    }
}