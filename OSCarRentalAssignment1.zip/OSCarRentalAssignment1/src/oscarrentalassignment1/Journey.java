/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oscarrentalassignment1;

/**
 *
 * @author Pamela Getalado
 */
public class Journey
{
    int distancetravelled;
    String journeycarbrand;
    int counter;
    Journey[] temp = new Journey[3];
    
    Journey()
    {
        distancetravelled = 0;
        journeycarbrand = "Unknown car brand";
    }
    void setJourneycarbrand(String brand)
    {
        journeycarbrand = brand;
    }
    
    String getJourneycarbrand()
    {
        return journeycarbrand;
    }
    
    void addJourneyCar(Journey carjourney)
    {
        temp[counter] = carjourney;
        counter++;
    }
    
    Journey getJourney (int index)
    {
        return temp [index];
    }
    
    void addJourneyCarTrip (Journey cartrip)
    {
        temp[counter] = cartrip;
        counter++;
    }
    
    Journey getJourneyCarTrip (int index)
    {
        return temp [index];
    }
    
    void setDistancetravelled(int km)
    {
        distancetravelled = km;
    }
    
    int getDistancetravelled()
    {
        return distancetravelled;
    }    
}
